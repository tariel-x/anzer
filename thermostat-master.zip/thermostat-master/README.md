# thermostat
Example using yacc and ragel

## Running

```
make
./thermostat
```
